﻿namespace DMS.Common.BaseParam
{
    public class BaseParam
    {
        public object Key { get; set; }
    }
}
